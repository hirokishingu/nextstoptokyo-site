# つぎは東京 — OpenStreetMap のデータ / OpenStreetMap data

作成日 / Made: 2026-10-28

## 日本語

iPhone 用のゲーム「つぎは東京」（Hiro Apps Shoten）は、OpenStreetMap のデータを加工して作っています。
Open Database License 1.0（ODbL）の第 4.6 条に従い、ゲームで使っている加工したデータと、
加工の方法をここで提供します。

- `derived/`：ゲームで使う形に加工したデータ（下の一覧）。元にした OpenStreetMap のデータは、
  2026-06-01, 2026-07-15, 2026-07-24, 2026-10-05, 2026-10-06, 2026-10-07 に Overpass API で取り出したもので、OpenStreetMap からだれでも取り出せます。

© OpenStreetMap contributors。データは ODbL 1.0 で利用できます：https://www.openstreetmap.org/copyright 、
https://opendatacommons.org/licenses/odbl/1-0/ 。このデータはゲームの風景用に形を直したもので、
地図・道案内・測量には使えません。

座標：東京駅（北緯 35.68100712 度、東経 139.766598352 度）を原点とする平面（GRS80 の接平面の近似）、
x は東向き、z は南向き（北の負）、単位はメートル。緯度・経度への戻し方は下の英語の欄の式。
線路・ホームの一部のファイルは、コースに沿った座標（s：快速のコースの始点からの距離、l：コースから左が正の横の距離）。

高さは入っていません。ゲームの高さは国土地理院の地理院タイル（標高タイル dem5a、
https://maps.gsi.go.jp/development/ichiran.html ）を各点の緯度・経度で双一次補間して取り、
高架橋・盛土・切り通しなどをゲーム用に直したものです。同じことをするには、各点を緯度・経度に戻して
標高タイルを読んでください。建物は国土交通省の 3D 都市モデル（Project PLATEAU）を加工したもので、
OpenStreetMap のデータではないため、ここには入れていません（https://www.mlit.go.jp/plateau/ ）。

お問い合わせ：hiro.apps.shoten@gmail.com

## English

The iPhone game つぎは東京 (Next Stop Tokyo, Hiro Apps Shoten) is built with OpenStreetMap data. As the Open
Database License 1.0 (section 4.6) asks, this archive offers the derived data the game uses and how it was made.

- `derived/`: the data in the form the game uses (listed below). The OpenStreetMap data it was made from was
  taken with the Overpass API on 2026-06-01, 2026-07-15, 2026-07-24, 2026-10-05, 2026-10-06, 2026-10-07 and can be had from OpenStreetMap by anyone.

© OpenStreetMap contributors, available under the ODbL 1.0: https://www.openstreetmap.org/copyright,
https://opendatacommons.org/licenses/odbl/1-0/. The derived data has been reshaped for the game's scenery and is
not fit for maps, navigation or surveying.

Co-ordinates: the course files, `up-track-osm.json` and the road files are in metres on a plane tangent at Tokyo
station (35.68100712 N, 139.766598352 E, GRS80), x east, z south (= -north). The track and platform files are in
course co-ordinates: s, metres along the rapid course (the running length of `course-rapid.json`'s samples), and
l, metres to its left (positive) or right. Back to latitude/longitude, with a = 6378137, e² = 0.00669438002290, φ0 the origin's latitude,
N = a / sqrt(1 - e² sin²φ0), M = a (1 - e²) / (1 - e² sin²φ0)^1.5:

    lat = 35.68100712 - z / M * 180 / π
    lon = 139.766598352 + x / (N cos φ0) * 180 / π

Heights are not included: the game's heights come from the GSI elevation tiles (dem5a,
https://maps.gsi.go.jp/development/ichiran.html), sampled bilinearly at each point's latitude/longitude, then
adjusted for viaducts, embankments and cuttings. Buildings come from Project PLATEAU (MLIT), which is not
OpenStreetMap data and is not included (https://www.mlit.go.jp/plateau/).

Contact: hiro.apps.shoten@gmail.com

## derived/

- `course-rapid.json`: the rapid service course (centre of our track), every `spacing` m
- `course-local.json`: the local service course
- `tracks.json`: railway ways, projected
- `up-track-osm.json`: the up rapid track the course was built from
- `parallels.json`: other trains' tracks in course co-ordinates: s (m along the course), l (m to its left/right), shift (corrections)
- `platforms.json`: platform outlines
- `platforms-extra.json`: platform outlines added for two stations
- `crossover-ochanomizu.json`: the crossover east of Ochanomizu
- `roads.json`: roads the cab sees (deck = on a bridge)
- `expressways.json`: Shuto expressways (bridge = elevated)
- `crossings.json`: lines crossing ours (subway, bridges)
- `road-decks.json`: road decks over the line

## How the derived data was made / 加工の方法

1. Ways tagged railway=* (tracks, platforms), highway=* and the Shuto expressways were taken from the extracts and
   projected with the formula above.
2. The rapid course: the ways of the Chuo rapid up track chained from Shinjuku platform 8 to the buffer stop past
   Tokyo platform 2 (`up-track-osm.json`; at each junction the way that turns least), resampled every 2 m and
   smoothed (Gaussian, 10 m), which keeps it within about half a metre of the OpenStreetMap line.
3. The local course: the Chuo-Sobu local up track from Shinjuku platform 13 to west of Ochanomizu, then the rapid
   course by the crossover there (`crossover-ochanomizu.json`), made the same way. This route is the game's own.
4. Other tracks: each running track near the line chained the same way and sampled every 4 m of the course where it
   is within 70 m of it, as (s, l), with `shift` for the game's corrections where tracks meet.
5. Roads: motorway to secondary roads and their links within 250 m of the line; ways that continue one another
   joined, resampled every 5 m; lanes and one-way from their tags, `deck` from bridge=yes. Expressways the same way.
6. Platforms: the OpenStreetMap platform outlines near the line, in course co-ordinates; two Shinjuku platforms
   (13/14, 15/16) the local service uses are in `platforms-extra.json`.
